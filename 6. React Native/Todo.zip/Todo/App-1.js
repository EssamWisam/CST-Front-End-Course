import React, {useState} from 'react';
import { StyleSheet, Text, View, KeyboardAvoidingView, TextInput, TouchableOpacity, Keyboard} from 'react-native';


export default function App() {
  const [task, setTask] = useState();
  const [tasks, setTasks] = useState(['Hello', 'Bye']);

  
  return (

      <View style={styles.taskWrapper}>
          <Text style={styles.sectionTitle}> Today's Tasks</Text>

          <View style={styles.items}>
          
            {tasks.map((task, index) => { 
              return (
              <TouchableOpacity key={index} onPress={()=>completeTask(index)}>
              <Text> {task} </Text>
              </TouchableOpacity>
              )
              })
            }

          </View>


    </View>
  );
}

const styles = StyleSheet.create({

  taskWrapper: {
    flex: 1,
    backgroundColor: '#E8fAED',
    paddingTop: 50,
    paddingHorizontal: 20,
  },
    sectionTitle: {
      fontSize: 24,
      fontWeight: 'bold'
     },
    items: {
      marginTop: 30,
     },
     writeTaskWrapper : {
      position: 'absolute',
      bottom: 60,
      width: '100%',
      flexDirection: 'row',
      justifyContent: 'space-around',
      alignItems: 'center',
     },
    input : {
      paddingVertical: 15,
      paddingHorizontal: 15,
      backgroundColor: '#FFF',
      borderRadius: 60,
      borderColor: '#C0C0C0',
      borderWidth: 1,
      width: 250

    },
    addButtonWrapper : {
      width: 60,
      height: 60,
      backgroundColor: '#fff',
      borderRadius: 60,
      justifyContent: 'center',
      alignItems: 'center',
      borderColor: '#C0C0C0',
      borderWidth: 1,
    },
    addText : {

    },
});
