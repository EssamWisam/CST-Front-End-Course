import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import React, { useState, useEffect } from 'react';

import Navbar from './components/Navbar/Navbar';
import Home from './pages/Home/Home';
import Create from './pages/Create/Create';
import BlogDetails from './pages/BlogDetails/BlogDetails';
import txt from './file.txt';


function App() {
  const [text, setText] = useState("")

  useEffect(() => {
    // Fetch the YAML file using a relative path
    fetch(process.env.PUBLIC_URL + './file.txt')
      .then((response) => response.text())
      .then((data) => {
        // Parse the YAML data
        setText(data)
      })
      .catch((error) => {
        console.error('Error fetching or parsing YAML file:', error);
      });
    }, []);


  return (
    <Router>
      <div className="App">
        <h1>{txt} {text}</h1>
        <Navbar />
        <div className="content">
            <Switch>
              <Route exact path="/"><Home /></Route>
              <Route path="/create"><Create /></Route>
              <Route path="/blogs/:id"><BlogDetails /></Route>
            </Switch>
        </div>
      </div>
    </Router>
  );
}

export default App;
