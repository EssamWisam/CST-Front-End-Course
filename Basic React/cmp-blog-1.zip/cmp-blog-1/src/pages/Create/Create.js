import './css/main/Create.css';

const Create = () => {

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Clicked Submit!");
  }

  return (
    <div className="create">
      <h2>Add a New Blog</h2>
      <form onSubmit={handleSubmit}>
          <label>Blog title:</label>
          <input type="text" required  />
          <label>Blog body:</label>
          <textarea required ></textarea>
          <label>Blog author:</label>
          <input type="text" />
          <button>Add Blog</button>
      </form>
    </div>
  );
}
 
export default Create;