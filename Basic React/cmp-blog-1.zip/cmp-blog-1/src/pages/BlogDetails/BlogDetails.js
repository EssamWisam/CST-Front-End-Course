import './css/main/BlogDetails.css';

const BlogDetails = () => {

  const handleDelete = () => {
    alert('Clicked Delete!')
  }

  const blog = {
    title: 'My new website',
    author: 'Essam',
    body: 'lorem ipsum...',
  }

  return (
    <div className="blog-details">
        <article>
          <h2>{ blog.title }</h2>
          <p style={{fontStyle: 'italic'}}>Written by { blog.author }</p>
          <div><p style={{textAlign: 'justify', lineHeight: '1.5rem'}}>{ blog.body }</p></div>
          <button onClick={handleDelete}>delete</button>
        </article>
    </div>
  );
}
 
export default BlogDetails;