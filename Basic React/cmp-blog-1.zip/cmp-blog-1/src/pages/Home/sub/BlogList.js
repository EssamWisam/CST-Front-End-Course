import { Link } from 'react-router-dom';
import '../css/main/BlogList.css';

const BlogList = ({ blogs }) => {
  return (
    <>
    <h1 style={{color: '#061833'}}>Today's Blogs</h1>
    <div className="blog-list">
      {blogs.map(blog => (
        <div className="blog-preview" key={blog.id} >
          <Link to={`/blogs/${blog.id}`}>
            <h2>{ blog.title }</h2>
            <p>Written by { blog.author }</p>
          </Link>
        </div>
      ))}
    </div>
    </>
  );
}
 
export default BlogList;